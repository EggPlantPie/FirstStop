(function() {
  'use strict';

  const BUTTON_CLASS = 'ai-policy-check-button';

  function createCheckPolicyButton() {
    const button = document.createElement('div');
    button.textContent = 'Check Policy';
    button.className = `${BUTTON_CLASS} T-I J-J5-Ji aoO v7 T-I-atl L3`;
    button.setAttribute('role', 'button');
    button.style.marginRight = '10px';
    button.addEventListener('click', performPolicyCheck);
    return button;
  }

  function performPolicyCheck(event) {
    const composeBox = event.target.closest('.btC').closest('div[role="dialog"]');
    if (!composeBox) {
      console.error('Could not find compose box');
      return;
    }

    const emailBody = composeBox.querySelector('div[g_editable="true"][role="textbox"]');
    if (!emailBody) {
      console.error('Could not find email body');
      return;
    }

    const emailContent = emailBody.innerHTML; // Use innerHTML to get the formatted content
    
    chrome.runtime.sendMessage({action: "checkPolicy", emailContent: emailContent}, response => {
      if (response.success) {
        alert(`Policy check result: ${response.result}`);
      } else {
        alert(`Error: ${response.error}`);
      }
    });
  }

  function addCheckPolicyButton() {
    const toolbars = document.querySelectorAll('.btC');
    
    toolbars.forEach(toolbar => {
      if (toolbar.querySelector(`.${BUTTON_CLASS}`)) return;

      const sendButton = toolbar.querySelector('div[role="button"][data-tooltip^="Send"]');
      if (!sendButton) return;

      const checkPolicyButton = createCheckPolicyButton();
      sendButton.parentNode.insertBefore(checkPolicyButton, sendButton);
      console.log('Check Policy button added to toolbar');
    });
  }

  function attemptAddButton() {
    addCheckPolicyButton();
    console.log('Attempting to add Check Policy button');
  }

  function observeDOM() {
    const observer = new MutationObserver(() => {
      attemptAddButton();
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    console.log('DOM observer started');
  }

  function initExtension() {
    console.log('Initializing Check Policy extension');
    attemptAddButton();
    observeDOM();
    setInterval(attemptAddButton, 2000);
  }

  initExtension();
})();
