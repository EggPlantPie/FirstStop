const OPENAI_API_KEY = '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';
let savedPolicy = '';

console.log('Background script loaded');

chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed or updated');
});

chrome.runtime.onStartup.addListener(() => {
  console.log('Browser started');
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  console.log('Tab updated:', tabId, changeInfo, tab.url);
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "savePolicy") {
    savedPolicy = request.policy;
    console.log('Policy saved in background:', savedPolicy);
    sendResponse({ success: true });
    return true;
  } else if (request.action === "checkPolicy") {
    chrome.storage.sync.get('policy', function(data) {
      const policy = data.policy || 'Default policy: Ensure professional language and no sensitive information.';
      checkPolicyWithOpenAI(request.emailContent, policy)
        .then(result => sendResponse({success: true, result: result}))
        .catch(error => sendResponse({success: false, error: error.message}));
    });
    return true; // Indicates we will send a response asynchronously
  } else if (request.action === "checkPolicyOpenAI") {
    checkPolicyWithOpenAI(request.emailContent, savedPolicy)
      .then(result => {
        sendResponse({ success: true, result: result });
      })
      .catch(error => {
        console.error('Error checking policy with OpenAI:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;  // Indicates that the response is sent asynchronously
  }
});

async function checkPolicyWithOpenAI(emailContent, policy) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `
          You are a policy checker for email content. 
          
          In the response, please do not repeat the email. Please get straight to a short summary of the issues and include the quote to the specific clause(s) in the policy. Please use the original clause and do not recreate or rephrase the clause in the response.

          As an example, the structure of the response should be like this:

            
            If aligned, please respond:
            The email is aligned with the email policy. 

            If not aligned, please response start with "This email might not be aligned with our email policy." and then continue with the following structure for each issue found from the email content:

            {Quote of the clause from the policy}
            {a short summary why it is not aligned with this clause}
          `
        },
        {
          role: "user",
          content: `
          Please analyze the following email content and 
          provide feedback on any policy violations or areas 
          of concern based on the given policy:\n\n${emailContent}
          The current policy is: ${policy}. Please respond and quote only based on the current provided policy and do not add anything new to that policy.
          Please show as many issues as you find.
          `
        }
      ]
    })
  });

  if (!response.ok) {
    throw new Error(`OpenAI API request failed: ${response.statusText}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}
