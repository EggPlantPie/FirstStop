document.addEventListener('DOMContentLoaded', function() {
  const policyInput = document.getElementById('policyInput');
  const saveButton = document.getElementById('savePolicy');
  const statusMessage = document.getElementById('status');

  if (!policyInput || !saveButton || !statusMessage) {
    console.error('One or more required elements not found in the popup');
    return;
  }

  // Load saved policy when popup opens
  chrome.storage.sync.get('policy', function(data) {
    if (data.policy) {
      policyInput.value = data.policy;
    }
  });

  saveButton.addEventListener('click', function() {
    const policy = policyInput.value.trim();
    if (policy) {
      chrome.storage.sync.set({policy: policy}, function() {
        statusMessage.textContent = 'Policy saved successfully!';
        statusMessage.style.color = 'green';
        setTimeout(() => {
          statusMessage.textContent = '';
        }, 2000);
      });
    } else {
      statusMessage.textContent = 'Please enter a policy before saving.';
      statusMessage.style.color = 'red';
    }
  });
});
